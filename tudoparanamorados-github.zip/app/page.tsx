"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Heart, Gift, Sparkles, ShoppingCart, X } from "lucide-react"

interface ItemCarrinho {
  nome: string
  preco: number
}

export default function TudoParaNamorados() {
  const [carrinho, setCarrinho] = useState<ItemCarrinho[]>([])
  const [mostrarCarrinho, setMostrarCarrinho] = useState(false)

  const adicionarAoCarrinho = (nome: string, preco: number) => {
    setCarrinho([...carrinho, { nome, preco }])
    setMostrarCarrinho(true)
  }

  const removerItem = (index: number) => {
    const novoCarrinho = carrinho.filter((_, i) => i !== index)
    setCarrinho(novoCarrinho)
  }

  const calcularTotal = () => {
    return carrinho.reduce((total, item) => total + item.preco, 0)
  }

  const gerarMensagem = () => {
    if (carrinho.length === 0) return "Olá! Gostaria de saber mais sobre os produtos."
    let mensagem = "Olá! Gostaria de comprar:\n"
    let total = 0
    carrinho.forEach((item) => {
      mensagem += `- ${item.nome} (R$ ${item.preco.toFixed(2)})\n`
      total += item.preco
    })
    mensagem += `\nTotal: R$ ${total.toFixed(2)}`
    return mensagem
  }

  const finalizarPedido = () => {
    const mensagem = gerarMensagem()
    const url = `https://wa.me/5599999999999?text=${encodeURIComponent(mensagem)}`
    window.open(url, "_blank")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-red-50 to-pink-100 text-red-900">
      {/* Header */}
      <header className="bg-gradient-to-r from-red-100 to-pink-200 p-8 text-center shadow-lg relative">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Heart className="h-8 w-8 text-red-600 animate-pulse" />
          <h1 className="text-5xl font-bold bg-gradient-to-r from-red-600 to-pink-600 bg-clip-text text-transparent">
            TudoParaNamorados
          </h1>
          <Heart className="h-8 w-8 text-red-600 animate-pulse" />
        </div>
        <p className="text-xl font-semibold">✨ Presentes românticos que dizem tudo ❤️ ✨</p>
        <div className="flex items-center justify-center gap-4 mt-4">
          <div className="flex items-center gap-1 text-sm bg-red-100 px-3 py-1 rounded-full">
            <Gift className="h-4 w-4" />
            <span>Entrega Rápida</span>
          </div>
          <div className="flex items-center gap-1 text-sm bg-pink-100 px-3 py-1 rounded-full">
            <Sparkles className="h-4 w-4" />
            <span>Qualidade Premium</span>
          </div>
        </div>

        {/* Botão do Carrinho */}
        <button
          onClick={() => setMostrarCarrinho(!mostrarCarrinho)}
          className="absolute top-4 right-4 bg-red-500 text-white p-3 rounded-full shadow-lg hover:bg-red-600 transition-colors"
        >
          <ShoppingCart className="h-6 w-6" />
          {carrinho.length > 0 && (
            <span className="absolute -top-2 -right-2 bg-yellow-500 text-black text-xs rounded-full h-6 w-6 flex items-center justify-center font-bold">
              {carrinho.length}
            </span>
          )}
        </button>
      </header>

      {/* Carrinho Lateral */}
      {mostrarCarrinho && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-end">
          <div className="bg-white w-full max-w-md h-full p-6 shadow-xl overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-red-900">🛒 Seu Carrinho</h2>
              <button onClick={() => setMostrarCarrinho(false)} className="text-gray-500 hover:text-red-500">
                <X className="h-6 w-6" />
              </button>
            </div>

            {carrinho.length === 0 ? (
              <p className="text-gray-500 text-center py-8">Seu carrinho está vazio</p>
            ) : (
              <>
                <ul className="space-y-3 mb-6">
                  {carrinho.map((item, index) => (
                    <li key={index} className="flex justify-between items-center p-3 bg-pink-50 rounded-lg">
                      <div>
                        <span className="font-medium">{item.nome}</span>
                        <p className="text-sm text-gray-600">R$ {item.preco.toFixed(2)}</p>
                      </div>
                      <button onClick={() => removerItem(index)} className="text-red-500 hover:text-red-700 p-1">
                        <X className="h-4 w-4" />
                      </button>
                    </li>
                  ))}
                </ul>

                <div className="border-t pt-4">
                  <p className="text-xl font-bold text-red-900 mb-4">Total: R$ {calcularTotal().toFixed(2)}</p>
                  <a
                    href="https://mpago.li/1TjWkrD"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded flex items-center justify-center"
                  >
                    💳 Comprar com Mercado Pago
                  </a>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Página Inicial */}
      <section className="p-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-2 bg-gradient-to-r from-red-600 to-pink-600 bg-clip-text text-transparent">
            🔥 DESTAQUES DA SEMANA 🔥
          </h2>
          <p className="text-lg text-gray-700">Os presentes mais desejados pelos namorados!</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card className="bg-white shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border-2 border-pink-200">
            <CardContent className="p-6">
              <div className="relative">
                <img
                  src="/images/cesta-stitch-real.png"
                  alt="Cesta Romântica"
                  className="rounded-xl mb-4 w-full h-56 object-cover"
                />
                <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded-full text-xs font-bold animate-bounce">
                  🔥 OFERTA!
                </div>
              </div>
              <h3 className="text-2xl font-bold mb-2">💕 Cesta Amor Doce</h3>
              <p className="text-sm text-gray-600 mb-3">
                🎁 Cesta com Stitch, rosas vermelhas, Ferrero Rocher, Kit Kat, Twix e muito mais!
              </p>
              <div className="flex items-center gap-2 mb-3">
                <span className="text-sm line-through text-gray-400">R$ 129,90</span>
                <span className="text-2xl font-bold text-red-600">R$ 99,99</span>
                <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs font-bold">-23%</span>
              </div>
              <Button
                onClick={() => adicionarAoCarrinho("Cesta Amor Doce", 99.99)}
                className="w-full bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600 text-white font-bold py-3 text-lg shadow-lg"
              >
                💖 ADICIONAR AO CARRINHO
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Página de Produto */}
      <section className="p-8 bg-white mt-8 shadow-inner">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-2 bg-gradient-to-r from-red-600 to-pink-600 bg-clip-text text-transparent">
            ✨ DETALHES DO PRODUTO ✨
          </h2>
          <p className="text-lg text-gray-700">Veja todos os detalhes deste presente incrível!</p>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          <div className="w-full">
            <img
              src="/images/cesta-stitch-real.png"
              alt="Cesta Amor Doce - Kit completo com Stitch, chocolates e rosas"
              className="w-full h-80 md:h-96 object-cover rounded-xl shadow-lg"
            />
          </div>
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <h3 className="text-3xl font-bold">💕 Cesta Amor Doce</h3>
              <div className="bg-red-100 text-red-800 px-2 py-1 rounded text-sm font-bold">⭐ MAIS VENDIDO</div>
            </div>

            <p className="text-lg text-gray-700 leading-relaxed">
              🎁 O presente perfeito para demonstrar todo seu amor! Uma linda cesta artesanal com o adorável Stitch de
              pelúcia, rosas vermelhas frescas e uma seleção premium de chocolates: Ferrero Rocher, Kit Kat, Twix,
              Garoto, Lindt e POP's.
            </p>

            <div className="bg-pink-50 p-4 rounded-lg border-l-4 border-pink-400">
              <p className="font-semibold text-pink-800 mb-2">🌟 O QUE ESTÁ INCLUÍDO:</p>
              <ul className="space-y-2 text-sm text-gray-700">
                <li className="flex items-center gap-2">
                  <span className="text-green-500">✅</span>
                  <span>🧺 Cesta artesanal com laço vermelho e dourado</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-500">✅</span>
                  <span>🍫 Chocolates premium: Ferrero Rocher, Kit Kat, Twix, Lindt</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-500">✅</span>
                  <span>🧸 Pelúcia do Stitch com gravata borboleta (25cm)</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-500">✅</span>
                  <span>🌹 Buquê de rosas vermelhas frescas</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-500">✅</span>
                  <span>💌 Cartão personalizado GRÁTIS</span>
                </li>
              </ul>
            </div>

            <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
              <label className="block mb-2 font-bold text-yellow-800">💌 Mensagem personalizada (GRÁTIS):</label>
              <textarea
                className="w-full p-3 border-2 border-yellow-300 rounded-lg focus:border-yellow-500 focus:outline-none"
                placeholder="Digite aqui sua mensagem de amor... ❤️"
                rows={3}
              />
            </div>

            <div className="bg-gradient-to-r from-red-50 to-pink-50 p-6 rounded-lg border-2 border-red-200">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <span className="text-lg line-through text-gray-500">De: R$ 129,90</span>
                  <div className="flex items-center gap-2">
                    <span className="text-4xl font-bold text-red-600">R$ 99,99</span>
                    <span className="bg-green-500 text-white px-2 py-1 rounded text-sm font-bold animate-pulse">
                      ECONOMIZE R$ 30!
                    </span>
                  </div>
                </div>
              </div>
              <Button
                onClick={() => adicionarAoCarrinho("Cesta Amor Doce", 99.99)}
                className="w-full bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600 text-white font-bold py-4 text-xl shadow-xl transform hover:scale-105 transition-all duration-200"
              >
                💖 ADICIONAR AO CARRINHO 💖
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Página de Contato */}
      <section className="p-8 bg-gradient-to-r from-red-50 to-pink-100 mt-8 text-center">
        <h2 className="text-3xl font-bold mb-4 bg-gradient-to-r from-red-600 to-pink-600 bg-clip-text text-transparent">
          💬 FALE CONOSCO
        </h2>
        <p className="text-lg mb-6">Atendimento rápido e com muito carinho ❤️</p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <a
            href="https://instagram.com/tudoparanamorados.ofc"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-500 via-pink-500 to-orange-500 text-white px-6 py-3 rounded-xl shadow-lg hover:opacity-90 transform hover:scale-105 transition-all duration-200 font-bold"
          >
            📸 @tudoparanamorados.ofc
          </a>
          <div className="text-sm text-gray-600">📱 Siga-nos para novidades diárias!</div>
        </div>
      </section>

      {/* Rodapé */}
      <footer className="text-center p-6 text-sm text-gray-600 mt-8 bg-gradient-to-r from-pink-100 to-red-100">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Heart className="h-4 w-4 text-red-500" />
          <span>© 2025 TudoParaNamorados. Todos os direitos reservados.</span>
          <Heart className="h-4 w-4 text-red-500" />
        </div>
        <p className="text-xs">Feito com ❤️ para espalhar amor pelo mundo</p>
      </footer>
    </div>
  )
}
